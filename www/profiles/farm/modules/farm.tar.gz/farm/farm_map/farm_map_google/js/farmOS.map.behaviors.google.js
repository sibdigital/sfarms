(function () {
  farmOS.map.behaviors.google = {
    attach: function (instance) {
      instance.addBehavior('google');
    }
  };
}());
