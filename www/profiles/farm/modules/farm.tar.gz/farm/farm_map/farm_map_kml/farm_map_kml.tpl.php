<?php print '<?xml version="1.0" encoding="UTF-8"?>'; ?>

<kml xmlns = "http://earth.google.com/kml/2.1">
  <Document>
<?php if (!empty($content)) print $content; ?>
  </Document>
</kml>
