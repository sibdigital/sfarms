STIR-operations.csv: 2008 RUSLE2 manual
